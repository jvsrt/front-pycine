# Appcine: pycine front-end

Front-end em svelte para consumir dados do projeto pycine (fastapi).


## Dependências
- requer nodejs - [instalação](https://github.com/fscheidt/dev/blob/master/contents/nodejs.md)



